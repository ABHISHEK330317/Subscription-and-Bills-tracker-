
import { Link } from "react-router-dom";
import { FaExclamationTriangle } from "react-icons/fa";

export default function NotFound() {
  return (
    <div
      className="d-flex flex-column justify-content-center align-items-center vh-100 text-center bg-light"
    >
      <FaExclamationTriangle size={80} className="text-danger mb-4" />
      <h1 className="display-3 fw-bold text-dark">404</h1>
      <h4 className="mb-3 text-secondary">Oops! Page Not Found</h4>
      <p className="mb-4">
        The page you’re looking for doesn’t exist or has been moved.
      </p>
      <Link to="/" className="btn btn-primary px-4">
        Go Home
      </Link>
    </div>
  );
}
