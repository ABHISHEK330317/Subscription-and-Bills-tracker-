// src/pages/ManageSubscriptions.js
import React, { useEffect, useState } from "react";
import axios from "axios";
import { baseurl } from "../App";
import { FaEdit, FaTrashAlt, FaBell } from "react-icons/fa";

export default function ManageSubscriptions() {
  const userid = sessionStorage.getItem("userid");

  const [subscriptions, setSubscriptions] = useState([]);
  const [form, setForm] = useState({
    id: null,
    name: "",
    category: "",
    amount: "",
    frequency: "Monthly",
    start_date: "",
    due_date: "",
  });

  const categories = [
    "Entertainment",
    "Utilities",
    "Mobile",
    "Internet",
    "Software",
    "Insurance",
    "Loan",
    "Fitness",
    "Education",
    "Other",
  ];

  const fetchSubscriptions = async () => {
    try {
      const res = await axios.post(
        baseurl,
        new URLSearchParams({
          tag: "get_subscriptions",
          user_id: userid,
        }),
        {
          headers: {
            "Content-Type": "application/x-www-form-urlencoded",
          },
        }
      );

      const subs = Array.isArray(res.data.subscriptions)
        ? res.data.subscriptions
        : [];

      setSubscriptions(subs);
    } catch (err) {
      console.error("Error fetching subscriptions:", err);
      alert("Error fetching subscriptions.");
    }
  };

  useEffect(() => {
    fetchSubscriptions();
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const tag = form.id ? "update_subscription" : "add_subscription";
      const payload = new URLSearchParams({
        tag,
        user_id: userid,
        id: form.id || "",
        name: form.name,
        category: form.category,
        amount: form.amount,
        frequency: form.frequency,
        start_date: form.start_date,
        due_date: form.due_date,
      });

      const res = await axios.post(baseurl, payload, {
        headers: {
          "Content-Type": "application/x-www-form-urlencoded",
        },
      });

      alert(res.data.message || "Saved.");
      setForm({
        id: null,
        name: "",
        category: "",
        amount: "",
        frequency: "Monthly",
        start_date: "",
        due_date: "",
      });
      fetchSubscriptions();
    } catch (err) {
      console.error("Error in submit:", err);
      alert("Error saving data.");
    }
  };

  const handleEdit = (sub) => setForm({ ...sub });

  const handleDelete = async (id) => {
    if (!window.confirm("Are you sure you want to delete this?")) return;

    try {
      const payload = new URLSearchParams({
        tag: "delete_subscription",
        id,
      });

      const res = await axios.post(baseurl, payload, {
        headers: {
          "Content-Type": "application/x-www-form-urlencoded",
        },
      });

      alert(res.data.message || "Deleted.");
      fetchSubscriptions();
    } catch (err) {
      console.error("Error deleting:", err);
      alert("Error deleting.");
    }
  };

  return (
    <div className="container mt-4 mb-5">
      {/* Add/Edit Form */}
      <div className="card p-4 shadow-lg rounded-4 border-0">
        <h4 className="text-center mb-4">
          {form.id ? "Edit" : "Add"} Subscription
        </h4>
        <form onSubmit={handleSubmit} className="row g-3">
          <div className="col-md-6">
            <label className="form-label">Name</label>
            <input
              className="form-control shadow-sm"
              name="name"
              value={form.name}
              onChange={handleChange}
              required
            />
          </div>
          <div className="col-md-6">
            <label className="form-label">Category</label>
            <select
              className="form-select shadow-sm"
              name="category"
              value={form.category}
              onChange={handleChange}
              required
            >
              <option value="">-- Select --</option>
              {categories.map((cat) => (
                <option key={cat}>{cat}</option>
              ))}
            </select>
          </div>
          <div className="col-md-4">
            <label className="form-label">Amount (₹)</label>
            <input
              className="form-control shadow-sm"
              name="amount"
              type="number"
              value={form.amount}
              onChange={handleChange}
              required
            />
          </div>
          <div className="col-md-4">
            <label className="form-label">Frequency</label>
            <select
              className="form-select shadow-sm"
              name="frequency"
              value={form.frequency}
              onChange={handleChange}
            >
              <option>Monthly</option>
              <option>Yearly</option>
              <option>Weekly</option>
            </select>
          </div>
          <div className="col-md-4">
            <label className="form-label">Start Date</label>
            <input
              className="form-control shadow-sm"
              name="start_date"
              type="date"
              value={form.start_date}
              onChange={handleChange}
              required
            />
          </div>
          <div className="col-md-4">
            <label className="form-label">Due Date</label>
            <input
              className="form-control shadow-sm"
              name="due_date"
              type="date"
              value={form.due_date}
              onChange={handleChange}
              required
            />
          </div>
          <div className="col-md-12 text-end">
            <button className="btn btn-success px-4 shadow-sm">
              {form.id ? "Update" : "Add"}
            </button>
          </div>
        </form>
      </div>

      {/* Subscription List */}
      <div className="card mt-5 p-4 shadow-lg border-0 rounded-4">
        <h5 className="mb-3">Your Subscriptions</h5>

        <div className="table-responsive">
          <table className="table table-hover table-bordered table-striped shadow-sm">
            <thead className="table-dark">
              <tr>
                <th>Name</th>
                <th>Category</th>
                <th>Amount</th>
                <th>Frequency</th>
                <th>Start</th>
                <th>Due</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {subscriptions.length === 0 ? (
                <tr>
                  <td colSpan="7" className="text-center text-muted">
                    <strong>⚠️ No subscriptions found.</strong>
                  </td>
                </tr>
              ) : (
                subscriptions.map((sub) => (
                  <tr key={sub.id}>
                    <td>{sub.name}</td>
                    <td>{sub.category}</td>
                    <td>₹{sub.amount}</td>
                    <td>{sub.frequency}</td>
                    <td>{sub.start_date}</td>
                    <td>{sub.due_date}</td>
                    <td>
                      <button
                        className="btn btn-sm btn-warning me-2"
                        onClick={() => handleEdit(sub)}
                        title="Edit"
                      >
                        <FaEdit />
                      </button>
                      <button
                        className="btn btn-sm btn-danger"
                        onClick={() => handleDelete(sub.id)}
                        title="Delete"
                      >
                        <FaTrashAlt />
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
