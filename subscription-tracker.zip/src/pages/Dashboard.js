import React from "react";
import { Outlet, useNavigate } from "react-router-dom";
import NotFound from "./NotFound";

export default function Dashboard() {
  const navigate = useNavigate();
  const userid = sessionStorage.getItem("userid");
  const username = sessionStorage.getItem("username");

  const handleLogout = () => {
    localStorage.removeItem("user");
    sessionStorage.removeItem("userid");
    navigate("/");
  };

  if (!userid) return <NotFound />;

  const cards = [
    {
      title: "Manage Subscriptions",
      desc: "View, add, edit or delete subscriptions.",
      route: "manage",
      icon: "bi-credit-card-2-front",
    },
    {
      title: "Reminders",
      desc: "Check upcoming payment reminders.",
      route: "",
      icon: "bi-bell",
    },
  ];

  return (
    <div>
      <nav className="navbar navbar-expand-lg navbar-dark bg-dark shadow-sm"  style={{
          background: "linear-gradient(to right, #0f2027, #203a43, #2c5364)",
        }}>
        <div className="container-fluid">
          <span className="navbar-brand">Subscription & Bill Tracker</span>
          <div className="d-flex">
            <span className="navbar-text text-white me-3">
              Welcome, {username || "User"}
            </span>
            <button onClick={handleLogout} className="btn btn-danger btn-sm">
              Logout
            </button>
          </div>
        </div>
      </nav>

      <div className="container mt-3">
        <h2 className="text-center fw-bold mb-3">Dashboard</h2>
        <p className="text-center text-muted mb-2">
          Your bills, subscriptions, and reminders in one place.
        </p>

        <div className="row justify-content-center">
          {cards.map((card, idx) => (
            <div className="col-md-4 mb-1 " key={idx}>
              <div
                className="card  h-100 shadow rounded-4 border-1 hover-card "
                style={{ cursor: "pointer", transition: "transform 0.3s ease" }}
                onClick={() => navigate(card.route)}
              >
                <div className="card-body text-center">
                  <i className={`bi ${card.icon} fs-1 mb-3 text-primary`}></i>
                  <h5 className="card-title fw-semibold">{card.title}</h5>
                  <p className="card-text text-secondary">{card.desc}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      <Outlet />
    </div>
  );
}
