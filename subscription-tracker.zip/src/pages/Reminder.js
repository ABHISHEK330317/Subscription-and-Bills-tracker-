import React, { useEffect, useState } from "react";
import axios from "axios";
import { baseurl } from "../App";
import { FaBell, FaCalendarAlt, FaRupeeSign, FaClock } from "react-icons/fa";
import moment from "moment";

export default function Reminder() {
  const userid = sessionStorage.getItem("userid");
  const [reminders, setReminders] = useState([]);

  useEffect(() => {
    fetchReminders();
  }, []);

  const fetchReminders = async () => {
    try {
      const res = await axios.post(
        baseurl,
        new URLSearchParams({
          tag: "get_subscriptions",
          user_id: userid,
        }),
        {
          headers: {
            "Content-Type": "application/x-www-form-urlencoded",
          },
        }
      );

      const subs = Array.isArray(res.data)
        ? res.data
        : res.data.subscriptions || [];

      const today = new Date();
      const withRemainingDays = subs.map((sub) => {
        const due = new Date(sub.due_date);
        const diff = Math.ceil((due - today) / (1000 * 60 * 60 * 24));
        return { ...sub, remaining_days: diff };
      });

      const sorted = withRemainingDays.sort(
        (a, b) => a.remaining_days - b.remaining_days
      );

      setReminders(sorted);
    } catch (err) {
      console.error("Error fetching reminders:", err);
      alert("Error fetching reminders.");
    }
  };

  const handleMarkAsPaid = async (id, frequency, currentDueDate) => {
    try {
      // Use moment to calculate next due based on existing due date
      let nextDue = moment(currentDueDate);

      switch (frequency.toLowerCase()) {
        case "monthly":
          nextDue = nextDue.add(1, "months");
          break;
        case "yearly":
          nextDue = nextDue.add(1, "years");
          break;
        case "weekly":
          nextDue = nextDue.add(1, "weeks");
          break;
        default:
          nextDue = nextDue.add(30, "days");
      }

      const nextDueFormatted = nextDue.format("YYYY-MM-DD");

      const res = await axios.post(
        baseurl,
        new URLSearchParams({
          tag: "mark_as_paid",
          id: id,
          next_due: nextDueFormatted,
        }),
        {
          headers: {
            "Content-Type": "application/x-www-form-urlencoded",
          },
        }
      );

      if (res.data.error === 0) {
        alert("Marked as paid successfully.");
        fetchReminders(); // Refresh list
      } else {
        alert("Failed to mark as paid.");
      }
    } catch (error) {
      console.error("Error marking as paid:", error);
      alert("Something went wrong.");
    }
  };

  return (
    <div className="container mt-5">
      <div
        className="text-center p-4 mb-4 text-white rounded shadow-lg"
        style={{
          background: "linear-gradient(to right, #0f2027, #203a43, #2c5364)",
        }}
      >
        <h3>
          <FaBell className="me-2 text-warning" />
          Upcoming Subscription Reminders
        </h3>
        <p className="mb-0">Track your upcoming bills and due dates.</p>
      </div>

      <div className="row">
        {reminders.length === 0 ? (
          <div className="col-12 text-center">
            <div className="alert alert-info shadow-sm">
              No upcoming reminders.
            </div>
          </div>
        ) : (
          reminders.map((sub, i) => {
            const isDueSoon = sub.remaining_days <= 2;
            const dueDate = moment(sub.due_date).format("DD-MM-YYYY");

            const cardStyle = {
              transition: "transform 0.3s ease",
            };

            return (
              <div className="col-md-4 mb-4" key={i}>
                <div
                  className={`card h-100 shadow-lg border-1 ${
                    isDueSoon ? "bg-light-subtle" : ""
                  }`}
                  style={cardStyle}
                  onMouseEnter={(e) =>
                    (e.currentTarget.style.transform = "scale(1.03)")
                  }
                  onMouseLeave={(e) =>
                    (e.currentTarget.style.transform = "scale(1)")
                  }
                >
                  <div className="card-body">
                    <h5 className="card-title text-dark fw-bold d-flex justify-content-between align-items-center">
                      {sub.name}
                      <span
                        className={`badge ${
                          sub.remaining_days <= 2
                            ? "bg-danger"
                            : sub.remaining_days <= 10
                            ? "bg-warning text-dark"
                            : "bg-success"
                        }`}
                      >
                        {sub.remaining_days <= 0
                          ? "Due Today"
                          : `${sub.remaining_days} Day(s) Left`}
                      </span>
                    </h5>
                    <hr />
                    <p className="card-text fs-6">
                      <span className="d-block mb-2">
                        <strong>Category:</strong> {sub.category}
                      </span>
                      <span className="d-block mb-2">
                        <FaRupeeSign className="me-1 text-primary" />
                        <strong>Amount:</strong> ₹{sub.amount}
                      </span>
                      <span className="d-block mb-2">
                        <FaCalendarAlt className="me-1 text-success" />
                        <strong>Due Date:</strong> {dueDate}
                      </span>
                      <span className="d-block mb-2">
                        <strong>Frequency:</strong> {sub.frequency}
                      </span>
                      <span className="d-block mb-3">
                        <FaClock className="me-1 text-secondary" />
                        <strong>Reminder:</strong>{" "}
                        {sub.remaining_days <= 2 ? (
                          <span className="text-danger fw-bold">
                            Pay Immediately
                          </span>
                        ) : sub.remaining_days < 10 ? (
                          <span className="text-danger">
                            {sub.remaining_days} day(s) remaining
                          </span>
                        ) : (
                          <span>{sub.remaining_days} day(s) remaining</span>
                        )}
                      </span>

                      <button
                        className="btn btn-danger "
                        onClick={() =>
                          handleMarkAsPaid(sub.id, sub.frequency, sub.due_date)
                        }
                      >
                        Mark as Paid
                      </button>
                    </p>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}
