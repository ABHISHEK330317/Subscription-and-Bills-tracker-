// src/pages/RegisterPage.jsx
import React, { useState } from "react";
import axios from "axios";
import { Link, useNavigate } from "react-router-dom";
import { baseurl } from "../App";

export default function Registration() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);

  const navigate = useNavigate();

  const handleRegister = async (e) => {
    e.preventDefault(); 

    if (!name || !password || !email) {
      alert("Please fill all fields");
      return;
    }

    setLoading(true);

    try {
      const response = await axios.post(
        baseurl,
        new URLSearchParams({
          tag: "register",
          name,
          email,
          password,
        }),
        {
          headers: {
            "Content-Type": "application/x-www-form-urlencoded",
          },
        }
      );
      console.log(response);
      
      if (response.data.error === 0) {
        alert(response.data.message || "Registration successful.");
        navigate("/");
        setEmail("");
        setName("");
        setPassword("");
      } else {
        alert(response.data.message || "Email already registered!");
      }
    } catch (error) {
      console.error("Error", error);
      alert("An unexpected error occurred. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg d-flex justify-content-center align-items-center vh-100">
      <div
        className="card p-4 shadow"
        style={{
          minWidth: 350,
          maxWidth: 400,
          background: "rgba(99, 99, 99, 0.7)",
        }}
      >
        <h4 className="text-center mb-4 text-white">Registration</h4>
        <form onSubmit={handleRegister}>
          <div className="mb-3">
            <label className="form-label text-white">Full Name</label>
            <input
              type="text"
              className="form-control"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Enter your name"
            />
          </div>
          <div className="mb-3">
            <label className="form-label text-white">Email</label>
            <input
              type="email"
              className="form-control"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Enter email"
            />
          </div>
          <div className="mb-3">
            <label className="form-label text-white">Password</label>
            <input
              type="password"
              className="form-control"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Create password"
            />
          </div>
          <button className="btn btn-primary w-100" disabled={loading}>
            {loading ? "Registering..." : "Register"}
          </button>
        </form>
        <p className="mt-3 text-center text-light">
          Already have an account?{" "}
          <Link to="/" className="text-info">
            Login
          </Link>
        </p>
      </div>
    </div>
  );
}
