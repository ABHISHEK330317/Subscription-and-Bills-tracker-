// src/pages/LoginPage.jsx
import { useState } from "react";
import axios from "axios";
import { Link, useNavigate } from "react-router-dom";
import { baseurl } from "../App";

export default function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);

  const navigate = useNavigate();

  const handleLogin = async (e) => {
    e.preventDefault();
    if (!email || !password) {
      alert("Please fill in all fields");
      return;
    }
    setLoading(true);
    try {
      const response = await axios.post(
        baseurl,
        new URLSearchParams({
          tag: "login",
          email,
          password,
        }),
        {
          headers: {
            "Content-Type": "application/x-www-form-urlencoded",
          },
        }
      );
      if (response.data.error === 0) {
       sessionStorage.setItem("userid", response.data.id);
      sessionStorage.setItem("username", response.data.name);
        alert("Login successful");
        navigate("/dashboard");
      } else {
        alert(response.data.message || "Login failed.");
      }
    } catch (error) {
      console.error("Login Error:", error);
      alert("Login failed. Please try again later.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg d-flex justify-content-center align-items-center vh-100">
      <div
        className="card p-4 shadow"
        style={{
          minWidth: 350,
          maxWidth: 400,
          background: "rgba(99, 99, 99, 0.7)",
        }}
      >
        <h4 className="text-center mb-4 text-white">
          Subscription & Bill Tracker
        </h4>

        <form onSubmit={handleLogin}>
          <div className="mb-3">
            <label className="form-label text-white">Email</label>
            <input
              type="email"
              className="form-control"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Enter email"
            />
          </div>
          <div className="mb-3">
            <label className="form-label text-white">Password</label>
            <input
              type="password"
              className="form-control"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Enter password"
            />
          </div>
          <button className="btn btn-primary w-100" disabled={loading}>
            {loading ? "Logging in..." : "Login"}
          </button>
        </form>

        <p className="mt-3 text-center text-light">
          Don't have an account?{" "}
          <Link to="/register" className="text-info">
            Register
          </Link>
        </p>
      </div>
    </div>
  );
}
